import React, { useState, useEffect } from 'react';
import { ChevronLeft, MapPin, CreditCard, Wallet, ShieldCheck, StickyNote, AlertCircle, Smartphone, Copy, CheckCircle, Clock, Store } from 'lucide-react';
import { CartItem } from './CustomerApp';

interface CheckoutScreenProps {
  items: CartItem[];
  subtotal: number;
  tax: number;
  deliveryFee: number;
  total: number;
  location: string;
  fulfillmentType: 'DELIVERY' | 'PICKUP';
  onBack: () => void;
  onPlaceOrder: (notes: string, paymentMethod: 'FULL_PREPAID' | 'PARTIAL_COURIER', isTransfer: boolean) => void;
}

const CheckoutScreen: React.FC<CheckoutScreenProps> = ({
  items,
  subtotal,
  tax,
  deliveryFee,
  total,
  location,
  fulfillmentType,
  onBack,
  onPlaceOrder
}) => {
  const [deliveryNotes, setDeliveryNotes] = useState("");
  
  // Two-step payment selection
  const [paymentSource, setPaymentSource] = useState<'CARD' | 'TRANSFER'>('CARD');
  const [paymentAllocation, setPaymentAllocation] = useState<'FULL_PREPAID' | 'PARTIAL_COURIER'>('FULL_PREPAID');
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes in seconds

  // Financial Logic
  const foodTotal = subtotal + tax; 
  // If Pickup, ONLY allow Full Prepaid (Logic enforced in render/state init, but robust here too)
  const dueNow = paymentAllocation === 'FULL_PREPAID' ? total : foodTotal;
  const dueLater = paymentAllocation === 'FULL_PREPAID' ? 0 : deliveryFee;

  // Enforce FULL_PREPAID for Pickup on mount
  useEffect(() => {
      if (fulfillmentType === 'PICKUP') {
          setPaymentAllocation('FULL_PREPAID');
      }
  }, [fulfillmentType]);

  useEffect(() => {
    let timer: ReturnType<typeof setInterval>;
    if (showTransferModal && timeLeft > 0) {
        timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    }
    return () => clearInterval(timer);
  }, [showTransferModal, timeLeft]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handlePlaceOrderClick = () => {
      if (paymentSource === 'TRANSFER') {
          setShowTransferModal(true);
      } else {
          setIsProcessing(true);
          // Simulate Card Processing
          setTimeout(() => {
              onPlaceOrder(deliveryNotes, paymentAllocation, false);
              setIsProcessing(false);
          }, 2000);
      }
  };

  const handleConfirmTransfer = () => {
      setIsProcessing(true);
      setTimeout(() => {
          onPlaceOrder(deliveryNotes, paymentAllocation, true);
          setIsProcessing(false);
          setShowTransferModal(false);
      }, 1500);
  };

  return (
    <div className="h-full flex flex-col bg-gray-50 animate-in slide-in-from-right duration-300 relative">
      
      {/* Header */}
      <div className="bg-white px-4 py-4 border-b border-gray-100 flex items-center gap-2 sticky top-0 z-10 shadow-sm">
        <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <ChevronLeft size={24} className="text-gray-900" />
        </button>
        <h1 className="text-xl font-bold text-gray-900">Checkout</h1>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-6">
        
        {/* Delivery Address Section (Hidden if Pickup) */}
        {fulfillmentType === 'DELIVERY' ? (
            <section className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-3 flex items-center gap-2">
                <MapPin size={16} className="text-orange-600" /> Delivery Details
            </h2>
            <div className="mb-4">
                <p className="font-bold text-gray-900 text-lg mb-1">Apartment / Home</p>
                <p className="text-gray-600">{location}</p>
            </div>
            
            <div className="space-y-3">
                <div>
                    <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Phone Number</label>
                    <input 
                        type="tel" 
                        defaultValue="+234 800 123 4567" 
                        className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm font-medium focus:outline-none focus:border-orange-500"
                    />
                </div>
                <div>
                    <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Delivery Instructions</label>
                    <div className="relative">
                        <StickyNote size={16} className="absolute top-3 left-3 text-gray-400" />
                        <textarea 
                            value={deliveryNotes}
                            onChange={(e) => setDeliveryNotes(e.target.value)}
                            placeholder="e.g. Leave at door, Gate code 1234"
                            className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-9 pr-3 py-2 text-sm focus:outline-none focus:border-orange-500 h-20 resize-none"
                        />
                    </div>
                </div>
            </div>
            </section>
        ) : (
            <section className="bg-green-50 p-6 rounded-xl border border-green-200 shadow-sm text-center">
                <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Store size={24} />
                </div>
                <h2 className="text-lg font-bold text-green-900 mb-1">Self-Pickup Order</h2>
                <p className="text-green-700 text-sm">You will pick up this order directly from the restaurant.</p>
                <div className="mt-4 p-3 bg-white rounded-lg border border-green-100 text-left">
                    <p className="text-xs text-gray-500 uppercase font-bold mb-1">Pickup Location</p>
                    <p className="font-bold text-gray-900">Burger & Co. Lagos</p>
                    <p className="text-xs text-gray-500">12 Adetokunbo Ademola, VI</p>
                </div>
            </section>
        )}

        {/* Order Summary */}
        <section className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
           <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-3">Order Summary</h2>
           <div className="space-y-3 mb-4">
              {items.map((line, idx) => (
                  <div key={idx} className="flex justify-between items-start text-sm">
                      <div className="flex gap-2">
                          <span className="font-bold text-gray-900">{line.quantity}x</span>
                          <div>
                              <span className="text-gray-700">{line.item.name}</span>
                              {line.item.customization && (
                                  <p className="text-xs text-gray-500">{line.item.customization}</p>
                              )}
                          </div>
                      </div>
                      <span className="text-gray-900 font-medium">₦{(line.item.price * line.quantity).toLocaleString()}</span>
                  </div>
              ))}
           </div>
        </section>

        {/* Payment Configuration */}
        <section className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm space-y-6">
          <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wider flex items-center gap-2">
            <CreditCard size={16} className="text-orange-600" /> Payment Configuration
          </h2>

          {/* 1. Payment Method (Source) */}
          <div>
              <p className="text-xs font-bold text-gray-500 mb-2">Select Payment Method</p>
              <div className="grid grid-cols-2 gap-3">
                  <button 
                    onClick={() => setPaymentSource('CARD')}
                    className={`flex flex-col items-center justify-center p-4 rounded-xl border transition-all ${
                        paymentSource === 'CARD' ? 'border-orange-500 bg-orange-50 text-orange-700 ring-1 ring-orange-500' : 'border-gray-200 text-gray-600 hover:border-gray-300'
                    }`}
                  >
                      <CreditCard size={24} className="mb-2" />
                      <span className="text-sm font-bold">Credit/Debit Card</span>
                  </button>
                  <button 
                    onClick={() => setPaymentSource('TRANSFER')}
                    className={`flex flex-col items-center justify-center p-4 rounded-xl border transition-all ${
                        paymentSource === 'TRANSFER' ? 'border-orange-500 bg-orange-50 text-orange-700 ring-1 ring-orange-500' : 'border-gray-200 text-gray-600 hover:border-gray-300'
                    }`}
                  >
                      <Smartphone size={24} className="mb-2" />
                      <span className="text-sm font-bold">Bank Transfer</span>
                  </button>
              </div>
          </div>
          
          {/* 2. Payment Allocation */}
          <div>
             <p className="text-xs font-bold text-gray-500 mb-2">Payment Structure</p>
             <div className="space-y-3">
                {/* Full Prepaid */}
                <label className={`block relative p-4 rounded-xl border cursor-pointer transition-all ${paymentAllocation === 'FULL_PREPAID' ? 'border-orange-500 bg-orange-50 ring-1 ring-orange-500' : 'border-gray-200 hover:border-gray-300'}`}>
                    <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                            <div className={`p-1.5 rounded border border-gray-200 ${paymentAllocation === 'FULL_PREPAID' ? 'bg-white text-orange-600' : 'bg-gray-50 text-gray-400'}`}>
                                <CheckCircle size={20} />
                            </div>
                            <div>
                                <p className="font-bold text-gray-900">Pay Full Amount Now</p>
                                <p className="text-xs text-gray-500">Includes Food {fulfillmentType === 'DELIVERY' && '& Delivery Fee'}</p>
                            </div>
                        </div>
                        <input 
                            type="radio" 
                            name="allocation" 
                            checked={paymentAllocation === 'FULL_PREPAID'} 
                            onChange={() => setPaymentAllocation('FULL_PREPAID')}
                            className="accent-orange-600 w-5 h-5"
                        />
                    </div>
                </label>

                {/* Partial / Courier - Only show if Delivery */}
                {fulfillmentType === 'DELIVERY' && (
                    <label className={`block relative p-4 rounded-xl border cursor-pointer transition-all ${paymentAllocation === 'PARTIAL_COURIER' ? 'border-orange-500 bg-orange-50 ring-1 ring-orange-500' : 'border-gray-200 hover:border-gray-300'}`}>
                        <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-3">
                                <div className={`p-1.5 rounded border border-gray-200 ${paymentAllocation === 'PARTIAL_COURIER' ? 'bg-white text-green-600' : 'bg-gray-50 text-gray-400'}`}>
                                    <Wallet size={20} />
                                </div>
                                <div>
                                    <p className="font-bold text-gray-900">Courier Payment (Delivery Only)</p>
                                    <p className="text-xs text-gray-500">Pre-pay Food, Pay Rider Later</p>
                                </div>
                            </div>
                            <input 
                                type="radio" 
                                name="allocation" 
                                checked={paymentAllocation === 'PARTIAL_COURIER'} 
                                onChange={() => setPaymentAllocation('PARTIAL_COURIER')}
                                className="accent-orange-600 w-5 h-5"
                            />
                        </div>
                    </label>
                )}
             </div>
          </div>
          
          {/* Payment Breakdown for Partial Mode */}
          {paymentAllocation === 'PARTIAL_COURIER' && fulfillmentType === 'DELIVERY' && (
              <div className="bg-orange-50 border border-orange-100 p-4 rounded-xl animate-in fade-in">
                  <h3 className="text-xs font-bold text-orange-800 uppercase tracking-wider mb-2">Payment Split</h3>
                  <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-gray-700">Pay Now (Food + Tax)</span>
                      <span className="font-bold text-gray-900">₦{foodTotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center border-t border-orange-200 pt-2">
                      <span className="text-sm text-gray-700">Pay Rider (Cash/Transfer)</span>
                      <span className="font-bold text-gray-900">₦{dueLater.toLocaleString()}</span>
                  </div>
              </div>
          )}

          <div className="bg-gray-50 p-3 rounded-lg flex items-start gap-2">
                <AlertCircle size={16} className="text-gray-500 shrink-0 mt-0.5" />
                <p className="text-xs text-gray-500 leading-relaxed">
                    <strong>Note:</strong> Food cost is always pre-paid securely. 
                    {paymentSource === 'TRANSFER' && ' Mobile transfers must be completed within 10 minutes.'}
                </p>
          </div>
        </section>

        {/* Trust Badge */}
        <div className="flex justify-center items-center gap-2 text-xs text-gray-400 py-2">
            <ShieldCheck size={14} />
            <span>Secure 256-bit SSL Encrypted Payment</span>
        </div>
      </div>

      {/* Sticky Bottom Footer */}
      <div className="bg-white border-t border-gray-100 p-6 shadow-[0_-5px_20px_rgba(0,0,0,0.05)] z-20">
        <div className="space-y-2 mb-4">
            <div className="flex justify-between text-sm text-gray-600">
                <span>Subtotal</span>
                <span>₦{subtotal.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-sm text-gray-600">
                <span>VAT (7.5%)</span>
                <span>₦{tax.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-sm text-gray-600">
                <span>{fulfillmentType === 'PICKUP' ? 'Pickup' : 'Delivery'}</span>
                <span>{deliveryFee === 0 ? 'Free' : `₦${deliveryFee.toLocaleString()}`}</span>
            </div>
            <div className="flex justify-between text-xl font-bold text-gray-900 pt-2 border-t border-gray-100">
                <span>Total</span>
                <span>₦{total.toLocaleString()}</span>
            </div>
        </div>

        <button 
            onClick={handlePlaceOrderClick}
            disabled={isProcessing}
            className="w-full bg-orange-600 text-white font-bold py-4 rounded-xl text-lg shadow-lg shadow-orange-200 hover:bg-orange-700 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
        >
            {isProcessing ? (
                <>Processing...</>
            ) : (
                <>
                    {paymentAllocation === 'FULL_PREPAID' 
                        ? `Pay Full Amount ₦${total.toLocaleString()}` 
                        : `Pay Food ₦${foodTotal.toLocaleString()} & Order`
                    }
                </>
            )}
        </button>
      </div>

      {/* MOBILE TRANSFER MODAL */}
      {showTransferModal && (
          <div className="absolute inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center p-4 animate-in fade-in">
              <div className="bg-white w-full max-w-sm rounded-2xl p-6 shadow-2xl animate-in slide-in-from-bottom">
                  <div className="text-center mb-6">
                      <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center mx-auto mb-3">
                          <Smartphone size={24} />
                      </div>
                      <h2 className="text-xl font-bold text-gray-900">Complete Transfer</h2>
                      <div className="flex items-center justify-center gap-2 mt-2 text-orange-600 font-bold bg-orange-50 py-1 px-3 rounded-full w-fit mx-auto">
                          <Clock size={16} />
                          <span>{formatTime(timeLeft)}</span>
                      </div>
                  </div>

                  <div className="bg-gray-50 rounded-xl p-4 space-y-4 mb-6 border border-gray-200">
                      <div>
                          <p className="text-xs text-gray-500 uppercase font-bold mb-1">Bank Name</p>
                          <p className="font-medium text-gray-900">GTBank / Guaranty Trust</p>
                      </div>
                      <div className="relative">
                          <p className="text-xs text-gray-500 uppercase font-bold mb-1">Account Number</p>
                          <p className="font-mono text-lg font-bold text-gray-900">0123456789</p>
                          <button className="absolute right-0 top-1/2 -translate-y-1/2 text-orange-600 p-2">
                              <Copy size={16} />
                          </button>
                      </div>
                      <div>
                          <p className="text-xs text-gray-500 uppercase font-bold mb-1">Amount to Transfer</p>
                          <p className="font-bold text-2xl text-gray-900 text-orange-600">₦{dueNow.toLocaleString()}</p>
                      </div>
                      <div className="bg-yellow-50 p-2 rounded text-xs text-yellow-800 border border-yellow-200">
                          Reference Code: <strong>CRV-{Math.floor(Math.random()*10000)}</strong>
                      </div>
                  </div>

                  <button 
                      onClick={handleConfirmTransfer}
                      disabled={isProcessing}
                      className="w-full bg-orange-600 text-white font-bold py-3 rounded-xl shadow-lg shadow-orange-200 hover:bg-orange-700 active:scale-[0.98] transition-all"
                  >
                      {isProcessing ? 'Verifying...' : 'I Have Sent the Money'}
                  </button>
                  
                  <button 
                    onClick={() => setShowTransferModal(false)}
                    className="w-full mt-3 py-2 text-sm text-gray-500 font-semibold"
                  >
                      Cancel
                  </button>
              </div>
          </div>
      )}
    </div>
  );
};

export default CheckoutScreen;