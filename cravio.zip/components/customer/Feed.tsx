import React, { useState, useEffect } from 'react';
import { FoodItem, Restaurant } from '../../types';
import { FOOD_ITEMS, RESTAURANTS } from '../../constants';
import { Heart, Star, Clock, Plus, Sparkles, SearchX, MapPin, X } from 'lucide-react';
import { generateDishDescription } from '../../services/geminiService';

interface FeedProps {
  onAddToCart: (item: FoodItem, quantity: number, customization?: { text: string; price: number; variantId: string }) => void;
  searchQuery?: string;
  locationName?: string;
  onItemSelect: (item: FoodItem) => void; // Lifted state
  savedItemIds: Set<string>;
  onToggleSave: (e: React.MouseEvent, itemId: string) => void;
}

const Feed: React.FC<FeedProps> = ({ 
    onAddToCart, 
    searchQuery = "", 
    locationName = "Lagos", 
    onItemSelect,
    savedItemIds,
    onToggleSave
}) => {
  const [aiCaption, setAiCaption] = useState<string>("");
  const [featuredItem, setFeaturedItem] = useState<FoodItem | null>(null);
  const [selectedRestaurantId, setSelectedRestaurantId] = useState<string | null>(null);

  useEffect(() => {
    const randomItem = FOOD_ITEMS[Math.floor(Math.random() * FOOD_ITEMS.length)];
    setFeaturedItem(randomItem);
    generateDishDescription(randomItem).then(setAiCaption);
  }, []);

  const getRestaurant = (id: string) => RESTAURANTS.find(r => r.id === id);

  const filteredItems = FOOD_ITEMS.filter(item => {
    if (selectedRestaurantId && item.restaurantId !== selectedRestaurantId) return false;
    if (!searchQuery) return true;
    const lowerQuery = searchQuery.toLowerCase();
    const restaurant = getRestaurant(item.restaurantId);
    return (
        item.name.toLowerCase().includes(lowerQuery) ||
        item.description.toLowerCase().includes(lowerQuery) ||
        (restaurant && restaurant.name.toLowerCase().includes(lowerQuery))
    );
  });

  const isSearching = !!searchQuery;

  const handleQuickAdd = (e: React.MouseEvent, item: FoodItem) => {
      e.stopPropagation();
      onAddToCart(item, 1);
  };

  const handleRestaurantClick = (id: string) => {
      if (selectedRestaurantId === id) {
          setSelectedRestaurantId(null);
      } else {
          setSelectedRestaurantId(id);
      }
  };

  // Helper to format large like counts
  const formatLikes = (count: number) => {
      if (!count) return '0';
      if (count >= 1000) return (count / 1000).toFixed(1) + 'k';
      return count.toString();
  };

  return (
    <div className="pb-24 relative">
      
      {/* Restaurant Selection Row */}
      {!isSearching && (
        <>
            <div className="p-4 pt-2 flex justify-between items-end">
                <div>
                    <h1 className="text-2xl font-bold mb-1">Discover</h1>
                    <p className="text-gray-500 text-sm flex items-center gap-1">
                        <MapPin size={12} className="text-orange-600" /> 
                        Popular near {locationName.split(',')[0]}
                    </p>
                </div>
                {!selectedRestaurantId && (
                    <button className="text-xs font-bold text-orange-600 hover:text-orange-700">See all</button>
                )}
            </div>

            {selectedRestaurantId ? (
                <div className="px-4 pb-4 flex items-center gap-2">
                    <button 
                        onClick={() => setSelectedRestaurantId(null)}
                        className="bg-gray-200 p-1 rounded-full"
                    >
                        <X size={16} />
                    </button>
                    <span className="font-bold text-lg">
                        {getRestaurant(selectedRestaurantId)?.name}
                    </span>
                    <span className="text-sm text-gray-500">Menu</span>
                </div>
            ) : (
                <div className="flex gap-4 overflow-x-auto px-4 pb-6 no-scrollbar">
                    {RESTAURANTS.map(rest => (
                    <div 
                        key={rest.id} 
                        onClick={() => handleRestaurantClick(rest.id)}
                        className="flex flex-col items-center space-y-2 min-w-[72px] cursor-pointer group"
                    >
                        <div className={`w-16 h-16 rounded-full p-0.5 transition-all ${selectedRestaurantId === rest.id ? 'bg-orange-600 scale-110' : 'bg-gradient-to-tr from-orange-500 to-purple-600 hover:scale-105'}`}>
                            <div className="w-full h-full rounded-full border-2 border-white overflow-hidden relative">
                                <img src={rest.imageUrl} alt={rest.name} className="w-full h-full object-cover" />
                            </div>
                        </div>
                        <span className={`text-xs font-medium truncate w-full text-center ${selectedRestaurantId === rest.id ? 'text-orange-600 font-bold' : ''}`}>
                            {rest.name}
                        </span>
                    </div>
                    ))}
                </div>
            )}
        </>
      )}

      {/* Food Feed */}
      <div className={`space-y-2 ${isSearching ? 'pt-4' : ''}`}>
        {filteredItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-gray-400">
                <SearchX size={48} className="mb-2 opacity-50" />
                <p>No delicious matches found.</p>
                {selectedRestaurantId && (
                    <button 
                        onClick={() => setSelectedRestaurantId(null)}
                        className="mt-4 text-orange-600 font-bold text-sm"
                    >
                        Clear Filter
                    </button>
                )}
            </div>
        ) : (
            filteredItems.map((item) => {
            const restaurant = getRestaurant(item.restaurantId);
            const isFeatured = item.id === featuredItem?.id && !isSearching && !selectedRestaurantId;
            const isSaved = savedItemIds.has(item.id);

            return (
                <div key={item.id} className="bg-white border-b border-gray-100 pb-8 last:border-0">
                    {/* Header */}
                    <div className="flex items-center justify-between px-4 mb-3">
                        <div className="flex items-center gap-2">
                            <img src={restaurant?.imageUrl} className="w-9 h-9 rounded-full object-cover border border-gray-100 shadow-sm" alt="" />
                            <div>
                                <p className="text-sm font-bold text-gray-900 leading-tight">{restaurant?.name}</p>
                                <div className="flex items-center gap-2 text-xs text-gray-500">
                                    <span className="flex items-center gap-0.5 text-yellow-500 font-bold">
                                        <Star size={10} fill="currentColor" /> {restaurant?.rating}
                                    </span>
                                    <span>• {restaurant?.category}</span>
                                </div>
                            </div>
                        </div>
                        {/* Delivery Time Badge */}
                        <div className="bg-gray-50 px-3 py-1.5 rounded-full border border-gray-100 flex items-center gap-1.5">
                            <Clock size={12} className="text-gray-400" />
                            <span className="text-xs font-bold text-gray-700">{item.prepTimeMinutes + 15}m</span>
                        </div>
                    </div>

                    {/* Interactive Media Card */}
                    <div 
                        className="relative w-full bg-gray-100 cursor-pointer active:opacity-95 transition-opacity"
                        onClick={() => onItemSelect(item)} // Open Lifted Details Modal
                    >
                        {/* Aspect Ratio Container */}
                        <div className="relative aspect-[4/5] sm:aspect-square md:aspect-[16/9] overflow-hidden">
                            <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                            
                            {/* Overlay Gradient */}
                            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/60 pointer-events-none"></div>

                            {/* Featured AI Caption */}
                            {isFeatured && aiCaption && (
                                <div className="absolute top-4 left-4 right-4 z-10">
                                    <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-black/60 backdrop-blur-md rounded-full border border-white/10">
                                        <Sparkles className="text-yellow-400 w-3 h-3" />
                                        <span className="text-white text-xs font-medium italic">"{aiCaption}"</span>
                                    </div>
                                </div>
                            )}

                            {/* SOCIAL ACTIONS OVERLAY (Phase 2) */}
                            <div className="absolute right-4 bottom-24 flex flex-col items-center gap-4 z-20">
                                <div className="flex flex-col items-center gap-1">
                                    <button 
                                        onClick={(e) => onToggleSave(e, item.id)}
                                        className={`p-3 rounded-full backdrop-blur-sm transition-transform active:scale-90 ${
                                            isSaved ? 'bg-white/90 text-red-500' : 'bg-black/30 text-white hover:bg-black/50'
                                        }`}
                                    >
                                        <Heart size={24} fill={isSaved ? "currentColor" : "none"} strokeWidth={isSaved ? 0 : 2} />
                                    </button>
                                    <span className="text-white text-xs font-bold shadow-sm">{formatLikes(item.likes)}</span>
                                </div>
                            </div>

                            {/* Price Tag Overlay - Bottom Left */}
                            <div className="absolute bottom-4 left-4">
                                <h3 className="text-white font-bold text-xl shadow-sm">{item.name}</h3>
                                <p className="text-gray-200 text-sm line-clamp-1 opacity-90">{item.description}</p>
                            </div>

                            {/* Quick Add Button - Bottom Right */}
                            <div className="absolute bottom-4 right-4">
                                <button 
                                    onClick={(e) => handleQuickAdd(e, item)}
                                    className="bg-white text-black px-4 py-2 rounded-full font-bold shadow-lg flex items-center gap-1 active:scale-90 transition-transform hover:bg-gray-100"
                                >
                                    <span>₦{item.price.toLocaleString()}</span>
                                    <Plus size={16} className="bg-black text-white rounded-full p-0.5 ml-1" />
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            );
            })
        )}
      </div>
    </div>
  );
};

export default Feed;