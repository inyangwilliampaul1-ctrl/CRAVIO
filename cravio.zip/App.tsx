import React, { useState, useEffect } from 'react';
import { UserRole, FoodItem, Order, OrderStatus, Restaurant } from './types';
import AuthScreen from './components/AuthScreen';
import CustomerApp from './components/customer/CustomerApp';
import VendorDashboard from './components/vendor/VendorDashboard';
import RiderDashboard from './components/rider/RiderDashboard';
import AdminDashboard from './components/admin/AdminDashboard';

// Mock simple ID generation
const generateId = () => Math.random().toString(36).substr(2, 9);

export default function App() {
  const [currentRole, setCurrentRole] = useState<UserRole | null>(null);
  const [currentUserProfile, setCurrentUserProfile] = useState<Restaurant | undefined>(undefined);
  
  // Global App State (Shared 'Database' for demo purposes)
  const [orders, setOrders] = useState<Order[]>([]);

  // Simulation: Verify Mobile Payments
  useEffect(() => {
    const interval = setInterval(() => {
        setOrders(currentOrders => 
            currentOrders.map(order => {
                if (order.status === 'PAYMENT_PENDING') {
                    // Simulate verification delay passed (e.g. 5-10 seconds for demo)
                    // In real app this comes from backend webhook
                    if (Date.now() - order.timestamp > 5000) {
                        return { ...order, status: 'PLACED' };
                    }
                }
                return order;
            })
        );
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Handlers
  const handleLogin = (role: UserRole, vendorDetails?: Restaurant) => {
    setCurrentRole(role);
    if (role === 'VENDOR' && vendorDetails) {
        setCurrentUserProfile(vendorDetails);
    } else {
        // Reset or fetch existing profile logic would go here
        setCurrentUserProfile(undefined);
    }
  };

  const handleLogout = () => {
    setCurrentRole(null);
    setCurrentUserProfile(undefined);
  };

  const placeOrder = (
      items: { item: FoodItem; quantity: number }[], 
      paymentMethod: 'FULL_PREPAID' | 'PARTIAL_COURIER' = 'FULL_PREPAID',
      deliveryFee: number = 1500.00,
      isTransfer: boolean = false,
      fulfillmentType: 'DELIVERY' | 'PICKUP' = 'DELIVERY'
  ) => {
    if (items.length === 0) return;

    const subtotal = items.reduce((acc, { item, quantity }) => acc + item.price * quantity, 0);
    const tax = subtotal * 0.075; // 7.5% VAT in Nigeria
    const total = subtotal + tax + deliveryFee;

    const newOrder: Order = {
      id: generateId(),
      customerId: 'current_user',
      restaurantId: items[0].item.restaurantId,
      items: items,
      totalAmount: total,
      status: isTransfer ? 'PAYMENT_PENDING' : 'PLACED',
      timestamp: Date.now(),
      deliveryFee: deliveryFee,
      paymentMethod: paymentMethod,
      amountDueOnDelivery: paymentMethod === 'PARTIAL_COURIER' ? deliveryFee : 0,
      fulfillmentType: fulfillmentType
    };

    setOrders(prev => [...prev, newOrder]);
  };

  const updateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
  };

  // Router Logic
  if (!currentRole) {
    return <AuthScreen onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans">
      <main className="h-screen w-full">
        {currentRole === 'CUSTOMER' && (
          <CustomerApp 
            orders={orders} 
            onPlaceOrder={placeOrder} 
            onLogout={handleLogout} 
          />
        )}
        
        {currentRole === 'VENDOR' && (
            <div className="h-full flex flex-col">
                 <div className="bg-white p-4 shadow-sm flex justify-between items-center">
                    <span className="font-bold text-blue-600">Partner Portal</span>
                    <button onClick={handleLogout} className="text-sm text-gray-500">Log Out</button>
                 </div>
                 <div className="flex-1 overflow-auto">
                    <VendorDashboard 
                        orders={orders} 
                        onUpdateStatus={updateOrderStatus} 
                        vendorProfile={currentUserProfile}
                    />
                 </div>
            </div>
        )}
        
        {currentRole === 'RIDER' && (
            <div className="h-full flex flex-col">
                 <div className="bg-white p-4 shadow-sm flex justify-between items-center">
                    <span className="font-bold text-green-600">Rider App</span>
                    <button onClick={handleLogout} className="text-sm text-gray-500">Log Out</button>
                 </div>
                 <div className="flex-1 overflow-auto">
                    <RiderDashboard orders={orders} onUpdateStatus={updateOrderStatus} />
                 </div>
            </div>
        )}
        
        {currentRole === 'ADMIN' && (
             <div className="h-full flex flex-col">
                <div className="bg-white p-4 shadow-sm flex justify-between items-center">
                   <span className="font-bold text-gray-800">Admin Panel</span>
                   <button onClick={handleLogout} className="text-sm text-gray-500">Log Out</button>
                </div>
                <div className="flex-1 overflow-auto">
                   <AdminDashboard orders={orders} />
                </div>
           </div>
        )}
      </main>
    </div>
  );
}